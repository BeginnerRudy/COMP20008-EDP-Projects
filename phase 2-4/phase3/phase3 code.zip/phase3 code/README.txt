This the README.txt file of DataProcessing.ipynb

DataProcessing.ipynb coded in Python3.

This code file is aim to processing dataset "Avoidable_Death.csv" and "Health_Risk_Factor.csv".

The data processing can be viewed as two parts, data preprocessing and data visualization and analysis.



How to use DataProcessing.ipynb?

Open the file with JupyterNotebook, then clikc instruction "Run All" in the "Cell" menu in the bar at the top.

Caution: code can only run bu "Run All", cannnot run code bolck singly.

After running, the generated "new_avoidable.csv" is the file to be upload to AURIN to do further clustering.

Hope these instruction help.



By Renjie Meng

renjiem@student.unimelb.edu.aus

2018-05-08
